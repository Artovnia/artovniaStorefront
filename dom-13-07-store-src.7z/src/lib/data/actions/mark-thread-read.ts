"use server"

/**
 * Placeholder server action for marking threads as read
 * Functionality removed as requested and will be implemented later
 */
export async function markThreadAsRead(threadId: string): Promise<boolean> {
  // This function doesn't do anything now
  console.log('Mark as read functionality temporarily disabled')
  return true
}
