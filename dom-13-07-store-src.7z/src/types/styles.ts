export interface Style {
  id: number;
  name: string;
  href: string;
}
