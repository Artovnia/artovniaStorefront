export interface Brand {
  id: number;
  name: string;
  logo: string;
  href: string;
}
