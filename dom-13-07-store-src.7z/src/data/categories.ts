export const primeCategories = {
  menswear: 'Menswear',
  womenswear: 'Womenswear',
};

export const categories = {
  clothing: 'Clothing',
  footwear: 'Footwear',
  bags: 'Bags',
  accessories: 'Accessories',
  brands: 'Brands',
  'new-in': 'New in',
  sale: 'Sale',
};
