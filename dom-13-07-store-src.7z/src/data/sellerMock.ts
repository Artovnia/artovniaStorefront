export const seller = {
  id: "jason",
  name: "Jason",
  photo: "/images/product/seller-avatar.jpg",
  rating: 0,
  reviewCount: 0,
  verified: true,
  handle: "/sellers/jason",
  joinDate: "2017",
  sold: 126,
  description:
    "Designer collection garms from Japan<br />Buy with confidence & Pay as you wish/the most offer & Bundle deals, make reasonable offers & No refund",
  parcel: "Parcel 2",
  date: "11.01.24 - 20.01.24",
  reviews: [],
}
