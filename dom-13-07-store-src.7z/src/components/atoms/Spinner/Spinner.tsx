export const Spinner = () => {
  return (
    <div className="w-4 h-4 border-2 border border-primary border-b-transparent rounded-full animate-spin"></div>
  )
}
