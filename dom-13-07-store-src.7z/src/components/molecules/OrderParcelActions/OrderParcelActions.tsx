import { OrderCancel } from "@/components/cells/OrderCancel/OrderCancel"
import { OrderReturn } from "@/components/cells/OrderReturn/OrderReturn"

export const OrderParcelActions = ({ order }: { order: any }) => {
  // Only allow cancel for orders in "Zamówienie otrzymane" state (status === "pending" or "not_fulfilled")
  if (order.status === "pending" || order.status === "not_fulfilled") {
    return <OrderCancel order={order} />
  }
  
  // Only allow return for delivered orders (status === "delivered" or "completed")
  if (order.status === "delivered" || order.status === "completed" || 
      order.fulfillment_status === "delivered" || order.fulfillment_status === "completed") {
    return <OrderReturn order={order} />
  }
  
  return null
}