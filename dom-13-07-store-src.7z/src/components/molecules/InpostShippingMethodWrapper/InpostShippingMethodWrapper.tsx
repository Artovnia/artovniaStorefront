"use client"

import React, { useState, useCallback } from "react"
import { InpostParcelSelector } from "../InpostParcelSelector/InpostParcelSelector"
import { InpostParcelInfo } from "../InpostParcelInfo/InpostParcelInfo"
import { InpostParcelData } from "@/lib/services/inpost-api"
import { isInpostShippingOption, createInpostShippingData } from "@/lib/helpers/inpost-helpers"
import { HttpTypes } from "@medusajs/types"
import { Button } from "@/components/atoms"
import { Text } from "@medusajs/ui"
import { setShippingMethod } from "@/lib/data/cart"

type InpostShippingMethodWrapperProps = {
  shippingMethod: HttpTypes.StoreCartShippingMethod
  sellerId: string | undefined
  onComplete?: () => void
  onError?: (error: string) => void
}

export const InpostShippingMethodWrapper: React.FC<InpostShippingMethodWrapperProps> = ({
  shippingMethod,
  sellerId,
  onComplete,
  onError
}) => {
  // State for tracking if we need to show the parcel selector
  const [showParcelSelector, setShowParcelSelector] = useState<boolean>(false)
  
  // State for selected parcel data
  const [selectedParcel, setSelectedParcel] = useState<InpostParcelData | null>(() => {
    // Initialize from shipping method data if available
    if (shippingMethod.data?.parcel_machine) {
      const machine = shippingMethod.data.parcel_machine as Record<string, string>
      return {
        machineId: machine.id || '',
        machineName: machine.name || '',
        machineAddress: machine.address || '',
        machinePostCode: machine.postal_code || '',
        machineCity: machine.city || ''
      }
    }
    return null
  })
  
  // State for tracking loading
  const [isLoading, setIsLoading] = useState<boolean>(false)

  // Check if this shipping method is an InPost method
  const isInpostMethod = isInpostShippingOption(shippingMethod)

  /**
   * Handle parcel selection
   */
  const handleParcelSelected = useCallback(async (parcelData: InpostParcelData) => {
    if (!shippingMethod) {
      onError?.("No shipping method selected")
      return
    }
    
    setIsLoading(true)
    
    try {
      setSelectedParcel(parcelData)
      setShowParcelSelector(false)
      
      // Create shipping data with parcel information
      const shippingData = createInpostShippingData(parcelData)
      
      // Include seller ID if available
      if (sellerId) {
        // @ts-ignore
        shippingData.seller_id = sellerId
      }
      
      // Get the shipping option ID from the method
      // Medusa shipping methods can have different structures
      const optionId = 
        // @ts-ignore - Handle different possible structures
        shippingMethod.shipping_option_id || 
        // @ts-ignore
        shippingMethod.shipping_option?.id ||
        // @ts-ignore
        shippingMethod.option_id || 
        ''
      
      // Update the shipping method with the parcel data
      console.log('Updating shipping method with parcel data:', {
        optionId,
        data: shippingData
      })
      
      // Get the current cart ID - this should be from a hook or context in a real implementation
      // Since we don't have direct access to the cart ID from the shipping method,
      // we use the current cart from localStorage as a fallback
      const currentCartId = await (async () => {
        try {
          // Try to get it from shipping method first (depends on API response structure)
          // @ts-ignore - Different possible structures
          if (shippingMethod.cart_id) return shippingMethod.cart_id;
          // @ts-ignore
          if (shippingMethod.cart?.id) return shippingMethod.cart.id;
          
          // Get from localStorage as last resort
          const cartIdFromStorage = localStorage.getItem('medusa_cart_id');
          if (cartIdFromStorage) return JSON.parse(cartIdFromStorage);
          
          console.error('Could not determine cart ID for shipping method update');
          return '';
        } catch (e) {
          console.error('Error getting cart ID:', e);
          return '';
        }
      })();
      
      // Call Medusa API to update the shipping method
      await setShippingMethod({
        cartId: currentCartId,
        shippingMethodId: optionId,
        data: shippingData
      })
      
      // Notify parent that we're done
      onComplete?.()
    } catch (err) {
      console.error('Error setting parcel data:', err)
      onError?.(err instanceof Error ? err.message : 'Failed to set parcel data')
    } finally {
      setIsLoading(false)
    }
  }, [shippingMethod, sellerId, onComplete, onError])
  
  // If not an InPost method, return null
  if (!isInpostMethod) {
    return null
  }

  // If we have a selected parcel and we're not showing the selector, display the parcel info
  if (selectedParcel && !showParcelSelector) {
    return (
      <div className="mt-2">
        <InpostParcelInfo parcelData={selectedParcel} />
        <Button 
          onClick={() => setShowParcelSelector(true)}
          variant="tonal"
          className="mt-2 text-sm"
        >
          Zmień paczkomat
        </Button>
      </div>
    )
  }

  // If we need to show the selector but it's not shown yet, show a button to show it
  if (!showParcelSelector) {
    return (
      <div className="mt-3">
        <Text className="text-sm mb-2 text-ui-fg-subtle">
          Aby skorzystać z dostawy do paczkomatu, wybierz paczkomat.
        </Text>
        <Button 
          onClick={() => setShowParcelSelector(true)}
          variant="filled"
          loading={isLoading}
        >
          Wybierz paczkomat
        </Button>
      </div>
    )
  }

  // Otherwise show the parcel selector
  return (
    <div className="mt-3">
      <InpostParcelSelector 
        onSelect={handleParcelSelected} 
        initialValue={selectedParcel}
      />
    </div>
  )
}

export default InpostShippingMethodWrapper
