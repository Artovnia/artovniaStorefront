/**
 * Type declarations for color-utils module
 */

export function hexToBgClass(hex: string): string;
