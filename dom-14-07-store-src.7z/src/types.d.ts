declare module '*.lodash';
