export interface Category {
  id: number;
  name: string;
  image: string;
  href: string;
}
