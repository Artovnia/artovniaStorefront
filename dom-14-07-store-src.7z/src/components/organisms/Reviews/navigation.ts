export const navigation = [
  {
    label: "TO WRITE",
    href: "/user/reviews",
  },
  {
    label: "WRITTEN",
    href: "/user/reviews/written",
  },
]
