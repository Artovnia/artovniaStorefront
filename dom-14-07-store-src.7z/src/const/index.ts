export const PRODUCT_LIMIT = 12

export const PARENT_CATEGORIES = ["menswear", "womenswear"]
